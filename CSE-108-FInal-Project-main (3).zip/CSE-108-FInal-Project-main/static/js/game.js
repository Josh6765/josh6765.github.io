console.log("Game loaded");
